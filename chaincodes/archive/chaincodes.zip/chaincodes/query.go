//------------------------------------------------------------------------------
/* Copyright 2016 IBM Corp. All Rights Reserved.
 * IBM Blockchain POC for Bradesco
 * Made by IBM Brasil Innovation Team
 */
//------------------------------------------------------------------------------

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"time"

	"github.com/hyperledger/fabric/core/chaincode/shim"
)

var openTradesStr = "_opentrades" //Description for the key/value that will store all open trades
var merchantKey = "_merchants"
var paymentsKey = "_payments"
var tokensKey = "_tokens"
var transacoesKey = "_transacoes"
var quantTokens int
var merchantLista []Merchant
var paymentsLista []Payments
var transacoesLista []Transacao
var transacao Transacao
var tokensLista []Token
var err error

// /var logger = shim.NewLogger("BradescoChaincode")
var found = false

type Payments struct {
	ID          int        `json:"id_payment"`
	Descricao   string     `json:"desc_payment"`
	Tokens      []Token    `json:"Token"`
	MyMerchants []Merchant `json:"clientes"`
}

type Merchant struct {
	ID          int     `json:"id_merchant"`
	RazaoSocial string  `json:"razao_social"`
	Cnpj        string  `json:"cnpj"`
	Tokens      []Token `json:"Token"`
}

type Token struct {
	Value string `json:"token_value"`
	Owner string `json:"owner"`
}

type Transacao struct {
	IdComprador int     `json:"id_comprador"`
	IdVendedor  int     `json:"id_fornecedor"`
	QtdTokens   int     `json:"qtd_tokens"`
	Cotacao     float64 `json:"valor_cotacao"`
	Id          string  `json:"horario_transacao"`
}

// SimpleChaincode example simple Chaincode implementation
type SimpleChaincode struct {
}

//Depois precisamos ajustar o uso da msToTime nas transacoes
const (
	millisPerSecond     = int64(time.Second / time.Millisecond)
	nanosPerMillisecond = int64(time.Millisecond / time.Nanosecond)
)

func msToTime(ms string) (time.Time, error) {
	msInt, err := strconv.ParseInt(ms, 10, 64)
	if err != nil {
		return time.Time{}, err
	}

	return time.Unix(msInt/millisPerSecond,
		(msInt%millisPerSecond)*nanosPerMillisecond), nil
}

// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ------------------------------------------------------ Funções Default ----------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //

// ============================================================================================================================
// Main
// ============================================================================================================================
func main() {

	// logger.SetLevel(shim.LogDebug)

	// logLevel, _ := shim.LogLevel(os.Getenv("SHIM_LOGGING_LEVEL"))
	// shim.SetLoggingLevel(logLevel)

	err := shim.Start(new(SimpleChaincode))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}

// ============================================================================================================================
// Invoke - Our entry point for invocations
// ============================================================================================================================
func (t *SimpleChaincode) Invoke(stub *shim.ChaincodeStub, function string, args []string) ([]byte, error) {
	fmt.Println("invoke is running " + function)

	if function == "init" { //initialize the chaincode state, used as reset
		return t.Init(stub, "init", args)
	} else if function == "initdemo" { //deletes an entity from its state
		res, err := t.initDemo(stub, args)
		return res, err
	} else if function == "cashin" { //compra de tokens
		res, err := t.cashIn(stub, args)
		return res, err
	} else if function == "transferTokens" { //Transferência de tokens entre merchants
		res, err := t.transferTokens(stub, args)
		return res, err
	} else if function == "cashOut" {
		res, err := t.cashOut(stub, args)
		return res, err
	}

	return nil, errors.New("Received unknown function invocation")
}

// ============================================================================================================================
// Query - Our entry point for Queries
// ============================================================================================================================
func (t *SimpleChaincode) Query(stub *shim.ChaincodeStub, function string, args []string) ([]byte, error) {
	fmt.Println("query is running " + function)

	// Handle different functions
	if function == "read" { //read a variable
		return t.read(stub, args)
	}
	if function == "getTokens" { //retorna os valores de tokens de um peer
		return t.getTokens(stub, args)
	}
	if function == "getTransactions" { //Retorna todas as transações realizadas
		return t.getTransactions(stub, args)
	}

	fmt.Println("query did not find func: " + function) //error

	return nil, errors.New("Received unknown function query")
}

// ============================================================================================================================
// Read - read a variable from chaincode state
// P.S.: Essa função será utilizada para receber os valores de tokens dos merchants (payments e FI)
//============================================================================================================================
func (t *SimpleChaincode) read(stub *shim.ChaincodeStub, args []string) ([]byte, error) {
	var arguments, jsonResp string
	var err error

	if len(args) < 1 {
		return nil, errors.New("Essa função aceita argumentos! Apenas o primeiro será lido, mas ela recebe quantos você colocar.")
	}

	arguments = args[0]
	fmt.Print("arguments " + arguments)
	valAsbytes, err := stub.GetState(arguments) //get the var from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + arguments + "\"}"
		return nil, errors.New(jsonResp)
	}

	return valAsbytes, nil //send it onward
}

// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// -------------------------------------------------- Funções Personalizadas -------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------------------------------------- //

// ============================================================================================================================
// Init - Reset em todas as informações do peer
// ============================================================================================================================
func (t *SimpleChaincode) Init(stub *shim.ChaincodeStub, function string, args []string) ([]byte, error) {
	var Aval int
	var err error

	if len(args) != 1 {
		return nil, errors.New("Incorrect number of arguments. Expecting 1")
	}

	// Initialize the chaincode
	Aval, err = strconv.Atoi(args[0])
	if err != nil {
		return nil, errors.New("Expecting integer value for init")
	}

	// Write the state to the ledger
	err = stub.PutState("abc", []byte(strconv.Itoa(Aval))) //making a test var "abc", I find it handy to read/write to it right away to test the network
	if err != nil {
		return nil, err
	}

	return nil, nil
}

// ============================================================================================================================
// initDemo - Inicializa tudo o que é necessário para realizar testes
//
// 0 = ID do Payments
// 1 = Nome do Payments
// 2 = CNPJ do Payments
// 3 = Tokens do Payments
// 4 = ID do Merchant 1
// 5 = Nome do Merchant 1
// 6 = CNPJ do Merchant 1
// 7 = Tokens do Merchant 1
// 8 = ID do Merchant 2
// 9 = Nome do Merchant 2
// 10 = CNPJ do Merchant 2
// 11 = Tokens do Merchant 2
// ============================================================================================================================
func (t *SimpleChaincode) initDemo(stub *shim.ChaincodeStub, args []string) ([]byte, error) {

	var volume, err = strconv.Atoi(args[3])
	if err != nil {
		msg := "volume " + args[3]
		fmt.Println(msg)
		return nil, errors.New(msg)
	}

	var initTransacoes = Transacao{}
	var transacoesList []Transacao
	var initMerchants = Merchant{}
	var merchantsList []Merchant
	var initPayments = Payments{}
	var paymentsList []Payments
	var initTokens = Token{}
	var tokensList []Token

	initTransacoes.Id = "Genesis Transaction"
	initTransacoes.IdComprador = 0
	initTransacoes.IdVendedor = 0
	initTransacoes.Cotacao = 0.00
	initTransacoes.QtdTokens = 0

	//criando alguns Merchants & Payments pra teste  (lembrar de remover posteriormente)
	initPayments.ID, err = strconv.Atoi(args[0])
	if err != nil {
		msg := "initPayments.Id_payment " + args[0]
		fmt.Println(msg)
		return nil, errors.New(msg)
	}

	initPayments.Descricao = args[1]

	//Cria tokens
	for i := 0; i < volume; i++ {
		initTokens = generateToken(initPayments.Descricao)
		initPayments.Tokens = append(initPayments.Tokens, initTokens)
		tokensList = append(tokensList, initTokens)
	}

	//Cria o merchant 1
	initMerchants = generateMerchant(stub, args[4], args[5], args[6], args[7], args[1])
	initPayments.MyMerchants = append(initPayments.MyMerchants, initMerchants)
	merchantsList = append(merchantsList, initMerchants)
	paymentsList = append(paymentsList, initPayments)

	//Cria o merchant 2 (colocando Itaá como payments para testar outra função)
	initMerchants = generateMerchant(stub, args[8], args[9], args[10], args[11], "Itaá")
	initPayments.MyMerchants = append(initPayments.MyMerchants, initMerchants)
	merchantsList = append(merchantsList, initMerchants)
	paymentsList = append(paymentsList, initPayments)

	//Payments => putState()
	paymentsBytesToWrite, err := json.Marshal(&paymentsList)
	if err != nil {
		fmt.Println("Error marshalling paymentsBytesToWrite")
		return nil, errors.New("Error marshalling the keys")
	}

	err = stub.PutState(paymentsKey, paymentsBytesToWrite)
	if err != nil {
		fmt.Println("Error writting keys paymentsBytesToWrite")
		return nil, errors.New("Error writing the keys paymentsBytesToWrite")
	}

	//Merchant => putState()
	merchantsBytesToWrite, err := json.Marshal(&merchantsList)
	if err != nil {
		fmt.Println("Error marshalling keys")
		return nil, errors.New("Error marshalling the merchantsBytesToWrite")
	}

	err = stub.PutState(merchantKey, merchantsBytesToWrite)
	if err != nil {
		fmt.Println("Error writting keys paymentsBytesToWrite")
		return nil, errors.New("Error writing the keys paymentsBytesToWrite")
	}

	//Tokens => putState()
	tokensBytesToWrite, err := json.Marshal(&tokensList)
	if err != nil {
		fmt.Println("Error marshalling keys")
		return nil, errors.New("Error marshalling the tokensBytesToWrite")
	}

	err = stub.PutState(tokensKey, tokensBytesToWrite)
	if err != nil {
		fmt.Println("Error writting keys paymentsBytesToWrite")
		return nil, errors.New("Error writing the keys paymentsBytesToWrite")
	}

	//Inicializando as ocorrências de transacoes(genesys)
	transacoesList = append(transacoesList, initTransacoes)

	transacoesBytesToWrite, err := json.Marshal(&transacoesList)
	if err != nil {
		fmt.Println("Error marshalling transacoesBytesToWrite")
		return nil, errors.New("Error marshalling the keys")
	}

	err = stub.PutState(transacoesKey, transacoesBytesToWrite)
	if err != nil {
		fmt.Println("Error writting keys transacoesBytesToWrite")
		return nil, errors.New("Error writing the keys paymentsBytesToWrite")
	}

	return nil, nil

}

// ============================================================================================================================
// getTokens - retorna o valor dos tokens da conta de um peer
//
// 0 = ID do tipo do peer
// 1 = ID do peer
// ============================================================================================================================
func (t *SimpleChaincode) getTokens(stub *shim.ChaincodeStub, args []string) ([]byte, error) {

	var readDataM []Merchant
	var readDataP []Payments
	var quantTokens, IDPeer int

	if len(args) != 2 {
		return nil, errors.New("Número incorreto de argumentos. Esperando 2 (ID do tipo do peer e ID do peer)")
	}

	//Checa o tipo do peer para instanciar a variável
	if args[0] == merchantKey {
		fmt.Println("Procurando tokens de um merchant")
	} else if args[0] == paymentsKey {
		fmt.Println("Procurando tokens de um payments")
	} else {
		return nil, errors.New("Parâmetros inválidos. A função aceita somente Merchants e Payments como tipo.")
	}

	//Procura o peer no ledger
	jsonResp, err := t.read(stub, args)
	if err != nil {
		return nil, errors.New("Não foi possível ler os dados do ledger para o peer")
	}
	fmt.Println("Peer encontrado no ledger")

	//Converte de byte para o tipo correspondente
	if args[0] == merchantKey {
		json.Unmarshal(jsonResp, &readDataM)
	} else if args[0] == paymentsKey {
		json.Unmarshal(jsonResp, &readDataP)
	}
	fmt.Println("Peer convertido de byte para o tipo correto")

	//Checa se o ID está correto e depois conta a quantidade de tokens
	if args[0] == merchantKey {
		for i := range readDataM {
			ID := strconv.Itoa(readDataM[i].ID)
			if args[1] == ID {
				IDPeer, err = strconv.Atoi(ID)
				if err != nil {
					return nil, errors.New("Conversão Atoi inválida")
				}
				quantTokens = len(readDataM[i].Tokens)
			}
		}
	} else if args[0] == paymentsKey {
		for i := range readDataP {
			ID := strconv.Itoa(readDataP[i].ID)
			if args[1] == ID {
				IDPeer, err = strconv.Atoi(ID)
				if err != nil {
					return nil, errors.New("Conversão Atoi inválida")
				}
				quantTokens = len(readDataP[i].Tokens)
			}
		}
	}
	fmt.Println("ID do peer: " + strconv.Itoa(IDPeer))
	fmt.Println("Quantidade de tokens do peer: " + strconv.Itoa(quantTokens))

	//Converte para byte
	valAsBytes, err := json.Marshal(quantTokens)
	if err != nil {
		return nil, errors.New("Conversão de string falhou")
	}
	fmt.Println("Chegou no fim da função! :)")

	return valAsBytes, nil //send it onward
}

// ============================================================================================================================
// getTransactions - retorna todas as transações realizadas. Possui um flag para retornar apenas as transações feitas com o Payments.
// PS.: só funciona com peers do tipo Payments (pode ser adaptada para outros tipos)!
//
// 0 = isPayments
// 1 = ID do payments (utilizada caso isPayments seja True)
// ===========================================================================================================================
func (t *SimpleChaincode) getTransactions(stub *shim.ChaincodeStub, args []string) ([]byte, error) {
	var readData []Transacao
	var isPayments bool
	var valAsBytes []byte

	if len(args) != 1 {
		return nil, errors.New("Número incorreto de argumentos. Esperando 1 (isPayments)")
	}

	argument := []string{transacoesKey}
	fmt.Printf("Array argument: " + argument[0])

	//Procura o peer no ledger
	jsonResp, err := t.read(stub, argument)
	if err != nil {
		return nil, errors.New("Não foi possível ler os dados do ledger para o peer")
	}
	fmt.Println("Peer encontrado no ledger")

	json.Unmarshal(jsonResp, &readData)
	fmt.Println("Unmarshal passado")

	//Caso seja payments, lê todas as transações e salva no retorno apenas as que tenham o ID do payments
	if isPayments {
		numArray := 0
		for i := range readData {
			idAtual, err := strconv.Atoi(args[1])
			if err != nil {
				return nil, errors.New("Erro na conversão de string")
			}
			if readData[i].IdComprador == idAtual {
				valAsBytes[numArray] = jsonResp[i]
				numArray++
			}
			if readData[i].IdVendedor == idAtual {
				valAsBytes[numArray] = jsonResp[i]
				numArray++
			}
		}
	} else { //Caso não seja payments, apenas iguala o array ao retorno
		valAsBytes, err = json.Marshal(readData)
	}

	fmt.Println("Chegou no fim da função :)")

	return valAsBytes, nil //Retorno
}

// ============================================================================================================================
// cashIn - Payments => Merchant && Payments na compra de Tokens
//
// 0 = ID do comprador
// 1 = Quantidade de tokens a ser comprada
// 2 = ID do vendedor
// 3 = Cotação atual
// 4 = Timestamp/ID da transação
// ============================================================================================================================
func (t *SimpleChaincode) cashIn(stub *shim.ChaincodeStub, args []string) ([]byte, error) {
	if len(args) != 6 {
		return nil, errors.New("Incorrect number of arguments. Expecting 6")
	}

	var isPayment = true //Condição que checa se o Payments está criando tokens ou se é apenas um cash in simples

	/*Recuperando os args*/
	comprador, err := strconv.Atoi(args[0])
	if err != nil {
		return nil, errors.New("Failed to get comprador")
	}
	quantTokens, err = strconv.Atoi(args[1])
	if err != nil {
		return nil, errors.New("Failed to get quantTokens")
	}

	vendedor, err := strconv.Atoi(args[2])
	if err != nil {
		return nil, errors.New("Failed to get vendedor")
	}

	cotacao, err := strconv.ParseFloat(args[3], 64)
	if err != nil {
		return nil, errors.New("Failed to get cotacao")
	}

	/*Recuperando os states de merchants,payments e transacoes - serao atualizados adiante*/
	merchantsAsBytes, err := stub.GetState(merchantKey)
	if err != nil {
		return nil, errors.New("Failed to get merchant list")
	}

	paymentsAsBytes, err := stub.GetState(paymentsKey)
	if err != nil {
		return nil, errors.New("Failed to get merchant list")
	}

	transacoesAsBytes, err := stub.GetState(transacoesKey)
	if err != nil {
		return nil, errors.New("Failed to get transacoes list")
	}

	json.Unmarshal(paymentsAsBytes, &paymentsLista)
	json.Unmarshal(merchantsAsBytes, &merchantLista)
	json.Unmarshal(transacoesAsBytes, &transacoesLista)

	//executando a transação de cashIn em si,primeiro busca o merchant com o args[0]-comprador
	for i := range merchantLista {
		if merchantLista[i].ID == comprador {
			isPayment = false
			fmt.Println("Cash in de Merchant: " + strconv.Itoa(comprador))

			//o próximo passo é identificar o payment que atenderá a solicitação segundo args[2] -> vendedor
			for x := range paymentsLista {
				if paymentsLista[x].ID == vendedor {
					//realiza a transferência de tokens do payment pro merchant
					for y := 0; y < quantTokens; y++ {

						//recuperando o ultimo token de payments para transferencia => merchant
						lastToken := paymentsLista[x].Tokens[len(paymentsLista[x].Tokens)-(y+1)]
						lastIndex := len(paymentsLista[x].Tokens) - (y + 1)
						merchantLista[i].Tokens = append(merchantLista[i].Tokens, lastToken)

						//delete tokens from last from payments(length-1)
						paymentsLista[x].Tokens = append(paymentsLista[x].Tokens[:lastIndex], paymentsLista[x].Tokens[lastIndex+1:]...)
					}

					merchantAsBytes, _ := json.Marshal(merchantLista[i])
					paymentsAsBytes, _ := json.Marshal(paymentsLista[x])

					//salvando um novo state com o id do merchant como key
					fmt.Println("salvando um novo state com o id do merchant como key: " + merchantLista[i].RazaoSocial)
					err = stub.PutState(strconv.Itoa(merchantLista[i].ID), merchantAsBytes)
					if err != nil {
						return nil, err
					}

					//salvando um novo state com o id do payment como key
					fmt.Println("salvando um novo state com o id do payment como key: " + paymentsLista[x].Descricao)
					err = stub.PutState(strconv.Itoa(paymentsLista[x].ID), paymentsAsBytes)
					if err != nil {
						return nil, err
					}

					paymentsListaAsBytes, _ := json.Marshal(paymentsLista)
					//salvando a nova versao da lista de Payments
					fmt.Println("salvando a nova versao da lista de Payments " + paymentsKey)
					err = stub.PutState(paymentsKey, paymentsListaAsBytes)
					if err != nil {
						return nil, err
					}

					merchantListaAsBytes, _ := json.Marshal(merchantLista)
					//salvando a nova versao da lista de Merchants
					fmt.Println("salvando a nova versao da lista de Merchants " + merchantKey)
					err = stub.PutState(merchantKey, merchantListaAsBytes)
					if err != nil {
						return nil, err
					}
				}
			}
		}
	}
	//fecha o loop de merchantLista
	if isPayment != false {
		//Neste ponto também precisamos subtrair do saldo de payments o equivalente aos tokens comprados
		var payment = Payments{}

		//recupera o state do payment registro individualmente
		paymentAsBytes, err := stub.GetState(strconv.Itoa(comprador))
		if err != nil {
			return nil, errors.New("Failed to get paymentAsBytes list")
		}

		json.Unmarshal(paymentAsBytes, &payment)
		fmt.Println("Cash in de Payment(disponibilizando Tokens no mercado) " + payment.Descricao)

		//recupera o list de tokens no state antes inicializado(initdemo)
		tokensAsBytes, err := stub.GetState(tokensKey)
		if err != nil {
			return nil, errors.New("Failed to get tokensAsBytes list")
		}

		json.Unmarshal(tokensAsBytes, &tokensLista)

		//criando tokens pela quantidade na requisicao de payments
		for q := 0; q < quantTokens; q++ {

			fmt.Println("Gerando Tokens em cashIn de payment " + strconv.Itoa(quantTokens))
			initTokens := generateToken(payment.Descricao)
			payment.Tokens = append(payment.Tokens, initTokens)
		}

		//atualiza o estado do payment(nova quantidade de tokens adquirida)
		paymentASBytes, _ := json.Marshal(payment)
		err = stub.PutState(strconv.Itoa(payment.ID), paymentASBytes)
		if err != nil {
			return nil, err
		}

		//Atualizando state da lista de merchants
		for x := range paymentsLista {
			if paymentsLista[x].ID == payment.ID {
				paymentsLista[x] = payment
			} else {
				fmt.Println("Erro ao buscar payment - atualizacao do list(CashIn): " + payment.Descricao)
				return nil, nil
			}
		}

		paymentsAsBytes, _ := json.Marshal(paymentsLista)
		//salvando um novo state com o id do payment como key
		fmt.Println("salvando um novo state da lista de payment#: " + payment.Descricao)
		err = stub.PutState(paymentsKey, paymentsAsBytes)
		if err != nil {
			return nil, err
		}

		tokensASBytes, _ := json.Marshal(tokensLista)
		err = stub.PutState(tokensKey, tokensASBytes)
		if err != nil {
			return nil, err
		}

	}

	//salvando a lista de Transacoes
	transacao.Cotacao = cotacao
	transacao.IdComprador = comprador
	transacao.IdVendedor = vendedor
	transacao.QtdTokens = quantTokens
	//precisamos utilizar o retorno da msToTime como nossos id's de transacao (args[4] - timestamp vindo da app,vira parametro pra msToTime)
	transacao.Id = args[4]

	transacoesLista = append(transacoesLista, transacao)
	transacoesListaAsBytes, _ := json.Marshal(transacoesLista)
	//salvando o state de transação
	fmt.Println("salvando o state de transação: " + transacoesKey)
	err = stub.PutState(transacoesKey, transacoesListaAsBytes)
	if err != nil {
		return nil, err
	}

	return nil, nil
}

// ============================================================================================================================
// cashOut - devolução de tokens
// 0 = ID do merchant
// 1 = Quantidade de tokens a ser transferida
// 2 = ID do payment
// 3 = Cotacao
// 4 = Timestamp/ID da transação
// ============================================================================================================================
func (t *SimpleChaincode) cashOut(stub *shim.ChaincodeStub, args []string) ([]byte, error) {
	if len(args) != 5 {
		return nil, errors.New("Incorrect number of arguments. Expecting 5")
	}

	var found = false
	var merchant = Merchant{}
	var payment = Payments{}
	merchant.ID, err = strconv.Atoi(args[0])
	payment.ID, err = strconv.Atoi(args[2])

	quantTokens, err = strconv.Atoi(args[1])
	if err != nil {
		return nil, errors.New("Failed to convert args[1](int)")
	}

	cotacao, err := strconv.ParseFloat(args[3], 64)
	if err != nil {
		return nil, errors.New("Failed to get cotacao")
	}

	/*Recuperando os states de merchants,payments e transacoes - serao atualizados adiante*/
	merchantsAsBytes, err := stub.GetState(merchantKey)
	if err != nil {
		return nil, errors.New("Failed to get merchant list")
	}

	paymentsAsBytes, err := stub.GetState(paymentsKey)
	if err != nil {
		return nil, errors.New("Failed to get merchant list")
	}

	transacoesAsBytes, err := stub.GetState(transacoesKey)
	if err != nil {
		return nil, errors.New("Failed to get transacoes list")
	}

	json.Unmarshal(paymentsAsBytes, &paymentsLista)
	json.Unmarshal(merchantsAsBytes, &merchantLista)
	json.Unmarshal(transacoesAsBytes, &transacoesLista)

	//executando a transação de cashIn em si,primeiro busca o merchant com o args[0]-comprador
	for i := range merchantLista {
		if merchantLista[i].ID == merchant.ID {
			found = true
			fmt.Println("Cash out de Merchant: " + strconv.Itoa(merchant.ID))

			//o próximo passo é identificar o payment que atenderá a solicitação segundo args[2] -> vendedor
			for x := range paymentsLista {
				if paymentsLista[x].ID == payment.ID {
					//realiza a transferência de tokens do payment pro merchant
					for y := 0; y < quantTokens; y++ {

						//recuperando o ultimo token de merchant para transferencia => payments
						lastToken := merchantLista[i].Tokens[len(merchantLista[i].Tokens)-(y+1)]
						lastIndex := len(merchantLista[i].Tokens) - (y + 1)
						paymentsLista[x].Tokens = append(paymentsLista[x].Tokens, lastToken)

						//delete tokens from last from merchant(length-1)
						merchantLista[i].Tokens = append(merchantLista[i].Tokens[:lastIndex], merchantLista[i].Tokens[lastIndex+1:]...)
					}

					merchantAsBytes, _ := json.Marshal(merchantLista[i])
					paymentsAsBytes, _ := json.Marshal(paymentsLista[x])

					//salvando um novo state com o id do merchant como key
					fmt.Println("salvando um novo state com o id do merchant como key: " + merchantLista[i].RazaoSocial)
					err = stub.PutState(strconv.Itoa(merchantLista[i].ID), merchantAsBytes)
					if err != nil {
						return nil, err
					}

					//salvando um novo state com o id do payment como key
					fmt.Println("salvando um novo state com o id do payment como key: " + paymentsLista[x].Descricao)
					err = stub.PutState(strconv.Itoa(paymentsLista[x].ID), paymentsAsBytes)
					if err != nil {
						return nil, err
					}

					paymentsListaAsBytes, _ := json.Marshal(paymentsLista)
					//salvando a nova versao da lista de Payments
					fmt.Println("salvando a nova versao da lista de Payments " + paymentsKey)
					err = stub.PutState(paymentsKey, paymentsListaAsBytes)
					if err != nil {
						return nil, err
					}

					merchantListaAsBytes, _ := json.Marshal(merchantLista)
					//salvando a nova versao da lista de Merchants
					fmt.Println("salvando a nova versao da lista de Merchants " + merchantKey)
					err = stub.PutState(merchantKey, merchantListaAsBytes)
					if err != nil {
						return nil, err
					}

					//salvando a lista de Transacoes
					transacao.Cotacao = cotacao
					transacao.IdComprador = payment.ID
					transacao.IdVendedor = merchant.ID
					transacao.QtdTokens = quantTokens
					//precisamos utilizar o retorno da msToTime como nossos id's de transacao (args[5] - timestamp vindo da app,vira parametro pra msToTime)
					transacao.Id = args[4]

					transacoesLista = append(transacoesLista, transacao)
					transacoesListaAsBytes, _ := json.Marshal(transacoesLista)
					//salvando o state de transação
					fmt.Println("salvando o state de transação(checkout): " + transacoesKey)
					err = stub.PutState(transacoesKey, transacoesListaAsBytes)
					if err != nil {
						return nil, err
					}
				}
			}
		}
	}

	if found == false {
		return nil, errors.New("Não foi possível encontrar o Merchant: " + strconv.Itoa(merchant.ID))
	}

	return nil, nil
}

// ============================================================================================================================
// transferTokens - Transferência de tokens entre merchants. Construída em cima da função de cashIn
// 0 = ID do receptor
// 1 = Quantidade de tokens a ser transferida
// 2 = ID do fornecedor
// 3 = Timestamp/ID da transação
// ============================================================================================================================
func (t *SimpleChaincode) transferTokens(stub *shim.ChaincodeStub, args []string) ([]byte, error) {
	if len(args) != 4 {
		return nil, errors.New("Incorrect number of arguments. Expecting 6")
	}
	var quantTokens int
	var merchantLista []Merchant
	var transacoesLista []Transacao
	var transacao Transacao
	var err error

	//Converte todos os parâmetros (string) em inteiros
	receptor, err := strconv.Atoi(args[0])
	if err != nil {
		return nil, errors.New("Não foi possível obter o receptor dos tokens")
	}
	quantTokens, err = strconv.Atoi(args[1])
	if err != nil {
		return nil, errors.New("Não foi possível obter a quantidade de tokens a ser transferida")
	}
	fornecedor, err := strconv.Atoi(args[2])
	if err != nil {
		return nil, errors.New("Não foi possível obter o fornecedor dos tokens")
	}

	//Busca as listas de merchants e de transações no ledger
	merchantsAsBytes, err := stub.GetState(merchantKey)
	if err != nil {
		return nil, errors.New("Não foi possível obter a lista de merchants do ledger")
	}
	transacoesAsBytes, err := stub.GetState(transacoesKey)
	if err != nil {
		return nil, errors.New("Não foi possível obter a lista de transações do ledger")
	}

	//Converte todos os dados de byte para um formato que possa ser lido pelo Go
	json.Unmarshal(merchantsAsBytes, &merchantLista)
	json.Unmarshal(transacoesAsBytes, &transacoesLista)

	//Itera entre todos os merchants, buscando o ID do receptor
	for i := range merchantLista {
		if merchantLista[i].ID == receptor {
			//Itera entre todos os merchants, buscando o ID do fornecedor
			for x := range merchantLista {
				if merchantLista[x].ID == fornecedor {
					fmt.Println("Realizando a transferência de tokens de " + strconv.Itoa(fornecedor) + " para " + strconv.Itoa(receptor) + "...")
					//Realiza a transferência de tokens
					for y := 0; y < quantTokens; y++ {

						//Recuperando o último token da conta do fornecedor para transferir para o receptor
						lastToken := merchantLista[x].Tokens[len(merchantLista[x].Tokens)-(y+1)]
						lastIndex := len(merchantLista[x].Tokens) - (y + 1)
						merchantLista[i].Tokens = append(merchantLista[i].Tokens, lastToken)

						//Deleta os tokens do fornecedor a partir do último da lista
						merchantLista[x].Tokens = append(merchantLista[x].Tokens[:lastIndex], merchantLista[x].Tokens[lastIndex+1:]...)
					}

					receptorAsBytes, _ := json.Marshal(merchantLista[i])
					fornecedorAsBytes, _ := json.Marshal(merchantLista[x])

					//Salva um novo state no ledger com os dados novos do receptor
					fmt.Println("Salvando um novo state no ledger para " + merchantLista[i].RazaoSocial + "...")
					err = stub.PutState(strconv.Itoa(merchantLista[i].ID), receptorAsBytes)
					if err != nil {
						return nil, err
					}

					//Salva um novo state no ledger com os dados novos do fornecedor
					fmt.Println("Salvando um novo state no ledger para " + merchantLista[x].RazaoSocial + "...")
					err = stub.PutState(strconv.Itoa(merchantLista[x].ID), fornecedorAsBytes)
					if err != nil {
						return nil, err
					}

					merchantListaAsBytes, _ := json.Marshal(merchantLista)
					//Salva a nova versão da lista de Merchants no ledger
					fmt.Println("Salvando a nova versão da lista de merchants: " + merchantKey + "...")
					err = stub.PutState(merchantKey, merchantListaAsBytes)
					if err != nil {
						return nil, err
					}
				}
			}
		}
	}

	//Adiciona as transações realizadas ao ledger
	transacao.IdComprador = receptor
	transacao.IdVendedor = fornecedor
	transacao.QtdTokens = quantTokens
	transacao.Id = args[3] //Timestamp

	transacoesLista = append(transacoesLista, transacao)
	transacoesListaAsBytes, _ := json.Marshal(transacoesLista)
	//salvando o state de transação
	fmt.Println("Salvando o state de transação " + transacoesKey + "...")
	err = stub.PutState(transacoesKey, transacoesListaAsBytes)
	if err != nil {
		return nil, err
	}

	fmt.Println("Transferência concluída.")

	return nil, nil
}

// ============================================================================================================================
// generateToken - Cria tokens
//
// owner = Payments provedor dos token
//
// PS.: Essa função retorna apenas um struct de Merchant! Para adicionar ao ledger, use um append para um array.
// ===========================================================================================================================
func generateToken(owner string) Token {
	var token = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	var initTokens = Token{}

	//Cria um hash para o token
	b := make([]rune, 10)
	for i := range b {
		b[i] = token[rand.Intn(len(token))]
	}

	//Assigna os parâmetros da função
	initTokens.Owner = owner
	initTokens.Value = string(b)

	return initTokens
}

// ============================================================================================================================
// generateMerchant - Cria merchants (para a initDemo)
//
// stub = shim
// ID = ID do merchant
// razaoSocial = nome da empresa
// CNPJ = CNPJ (esse é straightforward vai)
// numTokens = Número de tokens a serem criados
// tokenOwner = Payments dono dos tokens
//
// PS.: Essa função retorna apenas um struct de Merchant! Para adicionar ao ledger, use um append para um array.
// ===========================================================================================================================
func generateMerchant(stub *shim.ChaincodeStub, ID string, razaoSocial string, CNPJ string, numTokens string, tokenOwner string) Merchant {
	//Declaração de variáveis
	var initMerchants = Merchant{}
	var err error
	var intTokens int

	//Assigna os parâmetros da função ao struct temporário initMerchants
	initMerchants.ID, err = strconv.Atoi(ID)
	if err != nil {
		msg := "initMerchants.IdMerchant error: " + ID
		fmt.Println(msg)
		os.Exit(1)
	}
	initMerchants.RazaoSocial = razaoSocial
	initMerchants.Cnpj = CNPJ

	//Converte o parâmetro numTokens
	intTokens, err = strconv.Atoi(numTokens)
	if err != nil {
		msg := "intTokens error: " + numTokens
		fmt.Println(msg)
		os.Exit(1)
	}

	//Cria o número de tokens definido nos parâmetros da função
	for i := 0; i < intTokens; i++ {
		structTokens := generateToken(tokenOwner)
		initMerchants.Tokens = append(initMerchants.Tokens, structTokens)
	}

	//Adiciona os tokens na chave global de tokens no ledger
	tokensBytesToWrite, err := json.Marshal(&initMerchants.Tokens)
	if err != nil {
		fmt.Println("Error marshalling keys")
		os.Exit(1)
	}
	err = stub.PutState(tokensKey, tokensBytesToWrite)
	if err != nil {
		fmt.Println("Error writting keys paymentsBytesToWrite")
		os.Exit(1)
	}

	return initMerchants
}
